export const DIFFICULTY_SETTINGS = {
    beginner: { label: 'Beginner', grid: 3 }, // 3x3 = 9 pieces
    medium: { label: 'Medium', grid: 5 },     // 5x5 = 25 pieces
    hard: { label: 'Hard', grid: 8 },         // 8x8 = 64 pieces
};

export const PREDEFINED_IMAGES = [
    { id: 'img1', url: 'https://images.unsplash.com/photo-1542332213-31f87348057f?q=80&w=1000&auto=format&fit=crop', label: 'Mountain' },
    { id: 'img2', url: 'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?q=80&w=1000&auto=format&fit=crop', label: 'Nature' },
    { id: 'img3', url: 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=1000&auto=format&fit=crop', label: 'House' },
    { id: 'img4', url: 'https://images.unsplash.com/photo-1517404215738-15263e9f9178?q=80&w=1000&auto=format&fit=crop', label: 'City' },
    { id: 'img5', url: 'https://images.unsplash.com/photo-1535591273668-578e31182c4f?q=80&w=1000&auto=format&fit=crop', label: 'Ocean' },
];

export const generatePuzzle = (gridSide) => {
    const pieces = [];
    const totalPieces = gridSide * gridSide;

    for (let row = 0; row < gridSide; row++) {
        for (let col = 0; col < gridSide; col++) {
            pieces.push({
                id: `piece-${row}-${col}`,
                correctRow: row,
                correctCol: col,
                currentPos: null, // null means it's in the generic "tray" or "hand"
            });
        }
    }

    // Shuffle pieces for the tray
    return pieces.sort(() => Math.random() - 0.5);
};
