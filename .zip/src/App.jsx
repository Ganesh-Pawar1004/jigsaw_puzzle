import React, { useState, useEffect } from 'react';
import { DndContext, DragOverlay, MouseSensor, TouchSensor, useSensor, useSensors } from '@dnd-kit/core';
import { PuzzleBoard } from './components/PuzzleBoard';
import { PuzzlePiece } from './components/PuzzlePiece';
import SetupScreen from './components/SetupScreen';
import { generatePuzzle, DIFFICULTY_SETTINGS } from './utils/GameManager';
import { RefreshCw, Trophy } from 'lucide-react';
// import Confetti from 'react-confetti';

function App() {
  const [gameMode, setGameMode] = useState('setup'); // setup | play | win
  const [config, setConfig] = useState({ level: 'medium', img: '' });
  const [pieces, setPieces] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [win, setWin] = useState(false);

  // SEO: Read URL params on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const level = params.get('level');
    const img = params.get('img');
    if (level && img) {
      setConfig({ level, img });
      setGameMode('setup'); // Let user see what they are about to play, or auto-start?
      // Let's stick to setup but pre-filled.
    }
  }, []);

  const sensors = useSensors(
    useSensor(MouseSensor, { activationConstraint: { distance: 10 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 250, tolerance: 5 } })
  );

  const startGame = (level, img) => {
    setConfig({ level, img });
    const gridSide = DIFFICULTY_SETTINGS[level].grid;
    const newPieces = generatePuzzle(gridSide);
    setPieces(newPieces);
    setWin(false);
    setGameMode('play');
  };

  const handleDragStart = (event) => {
    setActiveId(event.active.id);
  };

  const handleDragEnd = (event) => {
    const { active, over } = event;
    setActiveId(null);

    if (over && active) {
      // Check if dropped in correct slot
      // active.data.current contains {row, col}
      // over.data.current contains {row, col}

      const pieceData = active.data.current;
      const slotData = over.data.current;

      console.log('Drop:', pieceData, slotData);

      if (pieceData.row === slotData.row && pieceData.col === slotData.col) {
        // Correct placement!
        setPieces((prev) => {
          const updated = prev.map(p => {
            if (p.id === active.id) {
              return { ...p, isPlaced: true, currentPos: { row: slotData.row, col: slotData.col } };
            }
            return p;
          });

          // Check win
          if (updated.every(p => p.isPlaced)) {
            setWin(true);
            // Optional: delay showing win screen?
          }
          return updated;
        });
      }
    }
  };

  const activePiece = activeId ? pieces.find(p => p.id === activeId) : null;
  const gridSide = DIFFICULTY_SETTINGS[config.level] ? DIFFICULTY_SETTINGS[config.level].grid : 3;

  return (
    <div className="min-h-screen bg-gray-900 text-white font-sans overflow-x-hidden">
      {win && <div className="absolute inset-0 pointer-events-none">🎉</div>}

      {gameMode === 'setup' && (
        <SetupScreen onStartGame={startGame} initialConfig={config} />
      )}

      {gameMode === 'play' && (
        <DndContext
          sensors={sensors}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <div className="flex flex-col lg:flex-row h-screen p-4 gap-4">

            {/* Left: The Board */}
            <div className="flex-1 flex flex-col items-center justify-center">
              <div className="mb-4 flex items-center gap-4">
                <button onClick={() => setGameMode('setup')} className="text-gray-400 hover:text-white flex items-center gap-2">
                  ← Back
                </button>
                <h2 className="text-2xl font-bold text-blue-400">Target</h2>
              </div>

              <PuzzleBoard
                gridSide={gridSide}
                pieces={pieces}
                imageUrl={config.img}
              />
            </div>

            {/* Right: The Tray (Unplaced Pieces) */}
            <div className="lg:w-1/3 bg-gray-800/50 p-4 rounded-xl border border-gray-700 flex flex-col">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold">Pieces ({pieces.filter(p => !p.isPlaced).length} left)</h3>
                <button onClick={() => startGame(config.level, config.img)} className="p-2 hover:bg-gray-700 rounded-full" title="Restart">
                  <RefreshCw size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto grid grid-cols-3 gap-2 content-start pr-2 custom-scrollbar">
                {pieces.filter(p => !p.isPlaced).map((piece) => (
                  <div key={piece.id} className="aspect-square relative">
                    <PuzzlePiece
                      {...piece}
                      row={piece.correctRow}
                      col={piece.correctCol}
                      gridSide={gridSide}
                      imageUrl={config.img}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Drag Overlay (Visual feedback while dragging) */}
          <DragOverlay zIndex={100}>
            {activePiece ? (
              <div className="w-24 h-24" style={{ cursor: 'grabbing' }}>
                {/* Note: Sizing helper. Real size depends on grid, but overlay might need fixed or dynamic size.
                     Actually, we should replicate the PuzzlePiece Visual. 
                     The helper inside PuzzlePiece handles size relative to parent 100%. 
                     Here in overlay, we need to be careful. 
                     Ideally we pass same props but style it to look lifted.
                 */}
                <PuzzlePiece
                  {...activePiece}
                  row={activePiece.correctRow}
                  col={activePiece.correctCol}
                  gridSide={gridSide}
                  imageUrl={config.img}
                  isPlaced={false} // Always show as unplaced in overlay
                />
              </div>
            ) : null}
          </DragOverlay>

          {/* Win Modal */}
          {win && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
              <div className="bg-gray-800 p-8 rounded-2xl text-center shadow-2xl border border-blue-500 max-w-md w-full animate-bounce-in">
                <Trophy size={64} className="mx-auto text-yellow-400 mb-4" />
                <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                  Puzzle Solved!
                </h2>
                <p className="text-gray-300 mb-8">
                  You completed the {DIFFICULTY_SETTINGS[config.level].label} puzzle!
                </p>
                <div className="flex gap-4 justify-center">
                  <button
                    onClick={() => setGameMode('setup')}
                    className="px-6 py-2 bg-gray-700 rounded-lg hover:bg-gray-600 font-semibold"
                  >
                    Menu
                  </button>
                  <button
                    onClick={() => startGame(config.level, config.img)}
                    className="px-6 py-2 bg-blue-600 rounded-lg hover:bg-blue-500 font-semibold"
                  >
                    Play Again
                  </button>
                </div>
              </div>
            </div>
          )}
        </DndContext>
      )}
    </div>
  );
}

export default App;
